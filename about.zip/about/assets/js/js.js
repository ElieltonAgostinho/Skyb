$(document).ready(function(){
	
	$(".aba:first").show();

	$("#nav-bar a").click(function(){
		$(".aba").hide();
		var div = $(this).attr('href');
		$(div).show();

		return false;
	});

	var userOnline = Number(jQuery('span.user_online').attr('id'));
	var clicou = [];
 
	function in_array(valor, array){
		for (var i = 0; i < array.length; i++) {
			if (array[i] == valor) {
				return true;
			}
		}
		return false;
	}

	function add_janela(id, nome, status){
		var janelas = Number($('#chats .window').length);
		var pixes = (270+5) * janelas;
		var style = 'float:none; position: absolute; bottom:0; left:'+pixes+'px;';

		var splitDados = id.split(':');
		var id_user = Number(splitDados[1]);

		var janela = '<div class = "window" id = "janela_'+id_user+'" style = "'+style+'">';
      	janela += '<div class = "header_window"><a href="#" class = "close">X</a><span class = "name">'+nome+'</span><span id ="'+id_user+'" class = "'+status+'"></span></div>';
      	janela += '<div class = "body"><div class = "mensagens"><ul></ul></div>';
        janela += '<div class = "send_message" id = "'+id+'"><input type = "text" name = "mensagem" class = "msg" id = "'+id+'"/></div></div></div>';

        jQuery('#chats').append(janela);

	}

	function retorna_historico(id_conversa){
		jQuery.ajax({
			type: 'POST',
			url: 'assets/php/historico.php',
			data: {conversacom: id_conversa, online: userOnline},
			dataType: 'json',
			success: function(retorno){
				jQuery.each(retorno, function(i, msg){
					if(jQuery('#janela_'+msg.janela_de).length > 0){
						if(userOnline == msg.id_de){
							jQuery('#janela_'+msg.janela_de+' .mensagens ul').append('<li id = "'+msg.id+'" class = "eu"><p>'+msg.mensagem+'</p></li>');
						}else{
							jQuery('#janela_'+msg.janela_de+' .mensagens ul').append('<li id = "'+msg.id+'"><div class = "imgSmall"><img src = "'+msg.fotoUser+'"></div><p>'+msg.mensagem+'</p></li>');
						}
					}
				});
				//[].reverse.call(jQuery('#janela_'+id_conversa+' .mensagens li')).appendTo('#janela_'+id_conversa+' .mensagens ul');
				//[].reverse.call(jQuery('#janela_'+id_conversa+' .mensagens li')).appendTo('#janela_'+id_conversa+' .mensagens ul');
				var altura = jQuery('#janela_'+id_conversa+' .mensagens').height();
				jQuery('#janela_'+id_conversa+' .mensagens').animate({scrollTop: altura}, '500');
			}
		});
	}

	function retorna_historico2(id_conversa){
		jQuery.ajax({
			type: 'POST',
			url: 'assets/php/historico2.php',
			data: {conversacom: id_conversa, online: userOnline},
			dataType: 'json',
			success: function(retorno){
				jQuery.each(retorno, function(i, msg){
					if(jQuery('#janela_'+msg.janela_de).length > 0){
						if(userOnline == msg.id_de){
							jQuery('#janela_'+msg.janela_de+' .mensagens ul').append('<li id = "'+msg.id+'" class = "eu"><p>'+msg.mensagem+'</p></li>');
						}else{
							jQuery('#janela_'+msg.janela_de+' .mensagens ul').append('<li id = "'+msg.id+'"><div class = "imgSmall"><img src = "'+msg.fotoUser+'"></div><p>'+msg.mensagem+'</p></li>');
						}
					}
				});
				//[].reverse.call(jQuery('#janela_'+id_conversa+' .mensagens li')).appendTo('#janela_'+id_conversa+' .mensagens ul');

				var altura = jQuery('#janela_'+id_conversa+' .mensagens').height();
				jQuery('#janela_'+id_conversa+' .mensagens').animate({scrollTop: altura}, '500');
			}

		});
		clearInterval(t);
				t = setTimeout(function(){
					jQuery.ajax({
								type: 'POST',
								url: 'assets/php/historico2.php',
								data: {conversacom: id_conversa, online: userOnline},
								dataType: 'json',
								success: function(retorno){
									jQuery.each(retorno, function(i, msg){
										if(jQuery('#janela_'+msg.janela_de).length > 0){
											if(userOnline == msg.id_de){
												jQuery('#janela_'+msg.janela_de+' .mensagens ul').append('<li id = "'+msg.id+'" class = "eu"><p>'+msg.mensagem+'</p></li>');
											}else{
												jQuery('#janela_'+msg.janela_de+' .mensagens ul').append('<li id = "'+msg.id+'"><div class = "imgSmall"><img src = "'+msg.fotoUser+'"></div><p>'+msg.mensagem+'</p></li>');
											}
										}
									});
									[].reverse.call(jQuery('#janela_'+id_conversa+' .mensagens li')).appendTo('#janela_'+id_conversa+' .mensagens ul');

									var altura = jQuery('#janela_'+id_conversa+' .mensagens').height();
									jQuery('#janela_'+id_conversa+' .mensagens').animate({scrollTop: altura}, '500');
								}
							});
				},1);
	}

	$('#batepapo a').click(function(){

		//alert("entrou!");
		var id = $(this).attr('id');
		jQuery(this).removeClass('comecar');

		var status = $(this).next().attr('class');
		var splitIds = id.split(':');
		var idJanela = Number(splitIds[1]);
			
		if (jQuery('#janela_'+idJanela).length == 0) {
			var nome = jQuery(this).text();
			add_janela(id, nome, status);
			retorna_historico(idJanela);
		}else{
			jQuery(this).removeClass('comecar');
		}
			
	});


	jQuery('body').on('click', '.header_window', function(){
		var next = jQuery(this).next();
		next.toggle(90);
	});

	jQuery('body').on('click', '.close', function(){
		var parent = jQuery(this).parent().parent();
		var idParent = parent.attr('id');
		var splitParent = idParent.split('_');
		var idJanelaFechada = Number(splitParent[1]);

		var contagem = Number(jQuery('.window').length)-1;
		var indice = Number(jQuery('.close').index(this));
		var restamAfrente = contagem - indice;
		
		for (var i = 1; i <= restamAfrente; i++) {
			jQuery('.window:eq('+(indice+i)+')').animate({left:"-=275"}, 200);
		}

		parent.remove();
		jQuery('#batepapo li#'+idJanelaFechada+' a').addClass('comecar');

	});

	jQuery('body').on('keyup', '.msg', function(e){
		if (e.which == 13) {
			var texto = jQuery(this).val();
			//alert(texto);
			var id = jQuery(this).attr('id');
			var split = id.split(':');
			var para = Number(split[1]);

			jQuery.ajax({
				type: 'POST',
				url: 'assets/php/submit.php',
				data: {mensagem: texto, de: userOnline, para: para},
				success: function(retorno){
					if(retorno == 'ok'){
						jQuery('.msg').val('');
					}else{
						alert("Ocorreu um erro ao enviar mensagem!");
					}
				}
			});
		}
	});

	jQuery('body').on('keyup', '.WhatsNew', function(e){
		if (e.which == 13) {
			var texto = jQuery(this).val();
			var cod = jQuery('.WhatsNewEm').val();

			//alert("id:"+cod);

			jQuery.ajax({
				type: 'POST',
				url: 'assets/php/post.php',
				data: {mensagem: texto, codId: cod},
				success: function(retorno){
					if(retorno == 'ok'){
						jQuery('.WhatsNew').val('');
					}else{
						alert("Ocorreu um erro ao fazer a postagem!");
						jQuery('.WhatsNew').val('');
					}
				}
			});
		}
	});

	jQuery('body').on('click', '.msg', function(){
		//var texto = jQuery(this).val();
			//alert(texto);
			var id = jQuery(this).attr('id');
			var split = id.split(':');
			var para = Number(split[1]);

			jQuery.ajax({
				type: 'POST',
				url: 'assets/php/updatemsg.php',
				data: {de: userOnline, para: para},
				success: function(retorno){
					if(retorno != 'ok'){
						alert("Ocorreu um erro");
					}
				}
			});
	});

	function verifica(timestamp, lastid, user){
		var t;
		jQuery.ajax({
			url: 'assets/php/stream.php',
			type: 'GET',
			data: 'timestamp='+timestamp+'&lastid='+lastid+'$user='+user,
			dataType: 'json',
			success: function(retorno){
				clearInterval(t);
				if (retorno.status == 'resultados' || retorno.status == 'vazio') {
					t = setTimeout(function(){
						verifica(retorno.timestamp, retorno.lastid, userOnline);
					},1000);

				if (retorno.status == 'resultados') {
					jQuery.each(retorno.dados, function(i, msg){
						if (jQuery('#janela_'+msg.janela_de).length == 0) {
							if(msg.janela_de != userOnline){
								jQuery('#batepapo #'+msg.janela_de+' .comecar').click();
								clicou.push(msg.janela_de);
							}
						}

						if (!in_array(msg.janela_de, clicou)) {
							if (jQuery('.mensagens ul li#'+msg.id).length == 0 && msg.janela_de > 0) {
								//alert(jQuery('.mensagens ul li#'+msg.id).length+" janela_de: "+msg.janela_de);
								if (userOnline == msg.id_de) {
									jQuery('#janela_'+msg.janela_de+' .mensagens ul').append('<li class = "eu" id = "'+msg.id+'"><p>'+msg.mensagem+'</p></li>');
								}else{
									jQuery('#janela_'+msg.janela_de+' .mensagens ul').append('<li id = "'+msg.id+'"><div class = "imgSmall"><img src = "'+msg.fotoUser+'"></div><p>'+msg.mensagem+'</p></li>');
								}
							}
						}
						//retorna_historico(janela_de);
						function ver(){
							retorna_historico2(msg.janela_de);
						}
						r = setInterval(ver,10000);
						setTimeout(r,20);
						clearInterval();
					});
					var altura = jQuery('.mensagens').height();
					jQuery('.mensagens').animate({scrollTop: -altura}, '500');
					console.log(clicou);
				}	
				clicou = [];
				}else if(retorno.status == 'erro'){
					alert('Error 9320: Atualize a página!');

				}
			},
			error: function(){
				clearInterval(t);
				t = setTimeout(function(){
					verifica(retorno.timestamp, retorno.lastid, userOnline);
					//retorna_historico(userOnline);
				},15000);
			}
		});
	}

	verifica(0,0,userOnline);


});
