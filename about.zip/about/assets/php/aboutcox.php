<?php

$mail = $_POST['inputEmail1'];

$nome = $_POST['text1'];
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_config1 = "mysql.hostinger.com.br";
$database_config1 = "u412875911_clien";
$username_config1 = "u412875911_root";
$password_config1 = "sesn3024";
$config1 = @mysql_pconnect($hostname_config1, $username_config1, $password_config1) or trigger_error(mysql_error(),E_USER_ERROR); 


$sql = @mysql_query("INSERT INTO `u412875911_clien`.`cliente` (`nome`, `email`) VALUES ('$nome','$mail');");

if($sql == true){
	header("Location: ../../about.html");
}
?>